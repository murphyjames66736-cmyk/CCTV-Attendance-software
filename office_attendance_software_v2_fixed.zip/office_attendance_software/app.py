import os, sqlite3, csv, io, secrets
from datetime import datetime, date
from zoneinfo import ZoneInfo
import time
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, render_template, request, redirect, url_for, session, flash, Response, abort

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get('DATABASE_PATH', os.path.join(BASE_DIR, 'attendance.db'))
TZ = ZoneInfo(os.environ.get('TIMEZONE', 'Asia/Karachi'))

def now_local():
    return datetime.now(TZ)

def today_str():
    return now_local().date().isoformat()

def now_str():
    return now_local().replace(tzinfo=None).isoformat(timespec='seconds')


def load_secret_key():
    key = os.environ.get('SECRET_KEY')
    if key:
        return key
    # Persist a generated key so all gunicorn workers and restarts share it.
    path = os.path.join(os.path.dirname(DB_PATH), '.secret_key')
    try:
        if os.path.exists(path):
            return open(path).read().strip()
        key = secrets.token_hex(32)
        with open(path, 'w') as f:
            f.write(key)
        os.chmod(path, 0o600)
        return key
    except OSError:
        return secrets.token_hex(32)

app = Flask(__name__)
app.secret_key = load_secret_key()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE','0') == '1', MAX_CONTENT_LENGTH=2 * 1024 * 1024)

@app.before_request
def protect_post_requests():
    if request.method == 'POST':
        submitted = request.form.get('_csrf_token', '')
        expected = session.get('_csrf_token', '')
        if not submitted or not expected or not secrets.compare_digest(submitted, expected):
            abort(400, description='The form security token is missing or expired. Refresh the page and try again.')

@app.context_processor
def inject_csrf_token():
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_urlsafe(32)
    return {'csrf_token': session['_csrf_token']}


def db():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    return conn


def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
          full_name TEXT NOT NULL, password_hash TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('admin','employee')), department TEXT DEFAULT '',
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS attendance (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
          work_date TEXT NOT NULL, check_in TEXT, check_out TEXT,
          source TEXT NOT NULL DEFAULT 'web', notes TEXT DEFAULT '',
          created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id),
          UNIQUE(user_id, work_date)
        );
        ''')
        admin_user = os.environ.get('ADMIN_USERNAME', 'admin')
        admin_pass = os.environ.get('ADMIN_PASSWORD', 'ChangeMeNow!2026')
        if (os.environ.get('RENDER') or os.environ.get('RAILWAY_ENVIRONMENT') or os.environ.get('FLY_APP_NAME')) and not os.environ.get('ADMIN_PASSWORD'):
            raise RuntimeError('Set ADMIN_PASSWORD to a strong unique password before deploying.')
        found = con.execute('SELECT id FROM users WHERE username=?', (admin_user,)).fetchone()
        if not found:
            con.execute('INSERT OR IGNORE INTO users(username,full_name,password_hash,role,department,created_at) VALUES(?,?,?,?,?,?)',
                        (admin_user, 'System Administrator', generate_password_hash(admin_pass), 'admin', 'Administration', now_str()))

init_db()

@app.context_processor
def common_context():
    return {'today': today_str(), 'current_year': now_local().year}


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login', next=request.path))
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            abort(403)
        return fn(*args, **kwargs)
    return wrapper


def current_user():
    if not session.get('user_id'): return None
    with db() as con:
        return con.execute('SELECT id,username,full_name,role,department,active FROM users WHERE id=?', (session['user_id'],)).fetchone()

@app.get('/')
def index():
    return redirect(url_for('dashboard') if session.get('user_id') else url_for('login'))

FAILED = {}  # (ip, username) -> list of timestamps
MAX_FAILS, WINDOW = 5, 600

def client_ip():
    return (request.headers.get('X-Forwarded-For', request.remote_addr or '').split(',')[0]).strip()

def throttled(key):
    now = time.time()
    FAILED[key] = [t for t in FAILED.get(key, []) if now - t < WINDOW]
    return len(FAILED[key]) >= MAX_FAILS

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        key = (client_ip(), username.lower())
        if throttled(key):
            flash('Too many failed attempts. Please wait 10 minutes and try again.', 'error')
            return render_template('login.html'), 429
        with db() as con:
            user = con.execute('SELECT * FROM users WHERE username=? AND active=1', (username,)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            FAILED.pop(key, None)
            session.clear()
            session['_csrf_token'] = secrets.token_urlsafe(32)
            session['user_id'] = user['id']; session['username'] = user['username']; session['role'] = user['role']
            return redirect(url_for('dashboard'))
        FAILED.setdefault(key, []).append(time.time())
        flash('Invalid username or password, or the account is disabled.', 'error')
    return render_template('login.html')

@app.post('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.get('/dashboard')
@login_required
def dashboard():
    user = current_user()
    if not user:
        session.clear(); return redirect(url_for('login'))
    if user['role'] == 'admin':
        with db() as con:
            total = con.execute("SELECT COUNT(*) n FROM users WHERE role='employee' AND active=1").fetchone()['n']
            present = con.execute('SELECT COUNT(*) n FROM attendance WHERE work_date=? AND check_in IS NOT NULL', (today_str(),)).fetchone()['n']
            open_shifts = con.execute('SELECT COUNT(*) n FROM attendance WHERE work_date=? AND check_in IS NOT NULL AND check_out IS NULL', (today_str(),)).fetchone()['n']
            recent = con.execute('''SELECT a.*,u.full_name,u.username FROM attendance a JOIN users u ON u.id=a.user_id ORDER BY a.work_date DESC,a.id DESC LIMIT 12''').fetchall()
        return render_template('admin_dashboard.html', user=user, total=total, present=present, open_shifts=open_shifts, recent=recent)
    with db() as con:
        today_row = con.execute('SELECT * FROM attendance WHERE user_id=? AND work_date=?', (user['id'],today_str())).fetchone()
        records = con.execute('SELECT * FROM attendance WHERE user_id=? ORDER BY work_date DESC LIMIT 20', (user['id'],)).fetchall()
    return render_template('employee_dashboard.html', user=user, today_row=today_row, records=records)

@app.post('/attendance/check-in')
@login_required
def check_in():
    user = current_user()
    if user['role'] != 'employee': abort(403)
    now = now_str()
    with db() as con:
        row = con.execute('SELECT * FROM attendance WHERE user_id=? AND work_date=?', (user['id'],today_str())).fetchone()
        if row and row['check_in']:
            flash('You have already checked in today.', 'error')
        elif row:
            con.execute("UPDATE attendance SET check_in=?, source='web' WHERE id=?", (now,row['id']))
            flash('Check-in recorded.', 'success')
        else:
            con.execute('INSERT INTO attendance(user_id,work_date,check_in,source,created_at) VALUES(?,?,?,?,?)', (user['id'],today_str(),now,'web',now))
            flash('Check-in recorded.', 'success')
    return redirect(url_for('dashboard'))

@app.post('/attendance/check-out')
@login_required
def check_out():
    user = current_user()
    if user['role'] != 'employee': abort(403)
    now = now_str()
    with db() as con:
        row = con.execute('SELECT * FROM attendance WHERE user_id=? AND work_date=?', (user['id'],today_str())).fetchone()
        if not row or not row['check_in']:
            flash('Check in before checking out.', 'error')
        elif row['check_out']:
            flash('You have already checked out today.', 'error')
        else:
            con.execute('UPDATE attendance SET check_out=? WHERE id=?', (now,row['id']))
            flash('Check-out recorded.', 'success')
    return redirect(url_for('dashboard'))

@app.route('/admin/employees', methods=['GET','POST'])
@admin_required
def employees():
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        full_name = request.form.get('full_name','').strip()
        password = request.form.get('password','')
        department = request.form.get('department','').strip()
        if not username or not full_name or len(password) < 10:
            flash('Enter a username, full name, and a temporary password of at least 10 characters.', 'error')
        else:
            try:
                with db() as con:
                    con.execute('INSERT INTO users(username,full_name,password_hash,role,department,created_at) VALUES(?,?,?,?,?,?)',
                        (username,full_name,generate_password_hash(password),'employee',department,now_str()))
                flash('Employee account created. Share the temporary password securely.', 'success')
            except sqlite3.IntegrityError:
                flash('That username already exists.', 'error')
        return redirect(url_for('employees'))
    with db() as con:
        people = con.execute("SELECT id,username,full_name,department,active,created_at FROM users WHERE role='employee' ORDER BY full_name").fetchall()
    return render_template('employees.html', people=people)

@app.post('/admin/employees/<int:user_id>/toggle')
@admin_required
def toggle_employee(user_id):
    with db() as con:
        row = con.execute("SELECT active FROM users WHERE id=? AND role='employee'", (user_id,)).fetchone()
        if not row: abort(404)
        con.execute('UPDATE users SET active=? WHERE id=?', (0 if row['active'] else 1,user_id))
    flash('Employee account status updated.', 'success')
    return redirect(url_for('employees'))

@app.route('/admin/attendance')
@admin_required
def attendance_report():
    start = request.args.get('start', now_local().date().replace(day=1).isoformat())
    end = request.args.get('end', today_str())
    person = request.args.get('employee','').strip()
    with db() as con:
        people = con.execute("SELECT id,full_name FROM users WHERE role='employee' ORDER BY full_name").fetchall()
        sql = '''SELECT a.*,u.full_name,u.username,u.department FROM attendance a JOIN users u ON u.id=a.user_id WHERE a.work_date BETWEEN ? AND ?'''
        args = [start,end]
        if person:
            sql += ' AND u.id=?'; args.append(person)
        sql += ' ORDER BY a.work_date DESC,u.full_name'
        rows = con.execute(sql,args).fetchall()
    return render_template('attendance_report.html', rows=rows, people=people, start=start, end=end, selected_employee=person)

@app.get('/admin/attendance/export.csv')
@admin_required
def export_csv():
    start = request.args.get('start', now_local().date().replace(day=1).isoformat())
    end = request.args.get('end', today_str())
    with db() as con:
        rows = con.execute('''SELECT u.username,u.full_name,u.department,a.work_date,a.check_in,a.check_out,a.source,a.notes FROM attendance a JOIN users u ON u.id=a.user_id WHERE a.work_date BETWEEN ? AND ? ORDER BY a.work_date DESC,u.full_name''',(start,end)).fetchall()
    out = io.StringIO(); writer = csv.writer(out)
    writer.writerow(['Username','Employee','Department','Date','Check-in','Check-out','Source','Notes'])
    for r in rows: writer.writerow([r['username'],r['full_name'],r['department'],r['work_date'],r['check_in'] or '',r['check_out'] or '',r['source'],r['notes'] or ''])
    return Response(out.getvalue(), mimetype='text/csv', headers={'Content-Disposition':f'attachment; filename=attendance_{start}_to_{end}.csv'})

@app.get('/healthz')
def healthz():
    return 'ok'

@app.route('/account/password', methods=['GET','POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current = request.form.get('current_password','')
        new = request.form.get('new_password','')
        confirm = request.form.get('confirm_password','')
        with db() as con:
            row = con.execute('SELECT password_hash FROM users WHERE id=?', (session['user_id'],)).fetchone()
            if not row or not check_password_hash(row['password_hash'], current):
                flash('Current password is incorrect.', 'error')
            elif len(new) < 10:
                flash('New password must be at least 10 characters.', 'error')
            elif new != confirm:
                flash('New passwords do not match.', 'error')
            else:
                con.execute('UPDATE users SET password_hash=? WHERE id=?', (generate_password_hash(new), session['user_id']))
                flash('Password updated.', 'success')
                return redirect(url_for('dashboard'))
    return render_template('change_password.html')

@app.post('/admin/employees/<int:user_id>/reset-password')
@admin_required
def reset_password(user_id):
    new = request.form.get('new_password','')
    if len(new) < 10:
        flash('Temporary password must be at least 10 characters.', 'error')
        return redirect(url_for('employees'))
    with db() as con:
        if not con.execute("SELECT id FROM users WHERE id=? AND role='employee'", (user_id,)).fetchone():
            abort(404)
        con.execute('UPDATE users SET password_hash=? WHERE id=?', (generate_password_hash(new), user_id))
    flash('Password reset. Share the new temporary password securely.', 'success')
    return redirect(url_for('employees'))

@app.errorhandler(400)
def bad_request(_):
    return render_template('error.html', code=400, message='The form security token is missing or expired. Refresh the page and try again.'), 400

@app.errorhandler(403)
def forbidden(_):
    return render_template('error.html', code=403, message='You do not have permission to access this page.'), 403

@app.errorhandler(404)
def not_found(_):
    return render_template('error.html', code=404, message='The requested page was not found.'), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
