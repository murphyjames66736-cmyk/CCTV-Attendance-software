# Office CCTV Attendance Software — Starter Release

A responsive web application with separate administrator and employee logins, employee account management, daily check-in/check-out, attendance history, date-filtered reports, CSV export, and session-based CSRF protection for form submissions. Built with Flask and SQLite, with Render and Docker deployment files included.

## Limitations

- The persistent disk that keeps the database across restarts needs a paid Render plan. The free tier sleeps and loses data.
- It does not read CCTV footage or recognize faces. Check-in and check-out are done by employees on the dashboard.
- It has no payroll, overtime or break rules, and it hasn't had an independent security audit.

## Important scope note

This release is a working **web attendance application**. Employee check-in/out is currently initiated through the employee dashboard. It does **not** yet identify faces from a live CCTV stream or automatically infer attendance from camera footage. CCTV/NVR models and network access vary; automatic camera ingestion needs a compatible RTSP/ONVIF stream and a securely configured on-site connector. Do not use facial recognition or biometric processing without appropriate notice, lawful basis, access controls, and retention rules.

## Run locally (Windows, macOS, or Linux)

1. Install Python 3.10 or newer.
2. Extract this ZIP and open a terminal in the extracted folder.
3. Create and activate a virtual environment (optional but recommended):
   - Windows PowerShell: `py -m venv .venv` then `.venv\\Scripts\\Activate.ps1`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Set a strong admin password before first launch. In PowerShell:
   ` $env:ADMIN_USERNAME="admin"; $env:ADMIN_PASSWORD="Use-A-Unique-Long-Password-Here!"; $env:SECRET_KEY="use-a-long-random-secret-here" `
   macOS/Linux: `export ADMIN_USERNAME=admin; export ADMIN_PASSWORD='Use-A-Unique-Long-Password-Here!'; export SECRET_KEY='use-a-long-random-secret-here'`
6. Start: `python app.py`
7. Open `http://127.0.0.1:5000` and sign in with the admin credentials you configured.

If you do not configure environment variables on first run, the local development default is username `admin` and password `ChangeMeNow!2026`. **Change this immediately and never use the default in a public deployment.** If the database already exists, changing `ADMIN_PASSWORD` does not reset the existing account password.

## Deploy to Render

1. Push the extracted project to a private GitHub repository.
2. In Render, choose **New → Blueprint** and select the repository containing `render.yaml`.
3. Enter a strong unique value for `ADMIN_PASSWORD` when prompted. Render generates `SECRET_KEY`; the included persistent disk stores the SQLite database.
4. Deploy and open the generated HTTPS URL.
5. Log in, add employee accounts, and share each employee's credentials privately.

The free Render web service may sleep and persistent disks may require a paid plan. Confirm current plan requirements in Render before deploying; a persistent disk is necessary to keep SQLite data across deploys/restarts. For larger teams or multiple app instances, use PostgreSQL rather than SQLite.

## Docker

Build and run:

```bash
docker build -t office-attendance .
docker run --rm -p 5000:5000 \
  -e SECRET_KEY='replace-with-long-random-secret' \
  -e ADMIN_USERNAME='admin' \
  -e ADMIN_PASSWORD='use-a-unique-long-password' \
  -v "$PWD/data:/var/data" \
  -e DATABASE_PATH=/var/data/attendance.db \
  office-attendance
```

## Updates in this version

- Timezone-aware timestamps (`TIMEZONE`, default `Asia/Karachi`) so check-ins are not recorded in server UTC.
- Password change page for every user and admin-initiated password reset.
- Login throttling (5 failures / 10 min per IP+username).
- Persistent auto-generated secret key if `SECRET_KEY` is unset; `/healthz` endpoint.

## Main routes

- `/login` — shared sign-in screen
- `/dashboard` — admin or employee dashboard according to role
- `/admin/employees` — admin-only employee management
- `/admin/attendance` — admin-only attendance reports
- `/admin/attendance/export.csv` — admin-only CSV export

## Production security checklist

- Set a strong `SECRET_KEY` and unique `ADMIN_PASSWORD`.
- Use HTTPS; `render.yaml` enables secure session cookies for HTTPS hosting.
- Limit who can access the admin account; do not share admin credentials with employees.
- Back up the database and restrict access to backups.
- Add a formal password-reset/change workflow, login throttling, audit logging, and automated tests before using this for sensitive payroll or compliance decisions.
- Validate attendance records with employees and office policy; this starter does not calculate payroll or enforce break/overtime rules.


Security note: This release includes session-based CSRF protection for POST forms and uses POST for logout. It has not received an independent security audit. Configure a unique strong `SECRET_KEY` and `ADMIN_PASSWORD` before deployment. Automatic CCTV recognition/ingestion is not included; check-in/out is currently recorded through the employee dashboard.
